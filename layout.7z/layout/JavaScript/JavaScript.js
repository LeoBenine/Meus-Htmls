document.addEventListener("DOMContentLoaded", () => {
  let clickCount = 0;
  let darkClickCount = 0;
  let mascoteTransformado = false;

  const mascote = document.getElementById("mascote");
  const mascoteDark = document.getElementById("mascote_dark");

  mascote.addEventListener("click", () => {
    if (mascoteTransformado) return;

    clickCount++;

    if (clickCount === 10) {
      mascoteTransformado = true;

      mascote.style.left = "-200px";
      mascote.style.opacity = "0";

      setTimeout(() => {
        mascoteDark.style.right = "50px";
        mascoteDark.style.opacity = "1";
        mascoteDark.style.pointerEvents = "auto";
      }, 600);
    }
  });

  mascoteDark.addEventListener("click", () => {
    if (!mascoteTransformado) return;

    darkClickCount++;

    if (darkClickCount === 10) {
      mascoteDark.style.right = "-200px";
      mascoteDark.style.opacity = "0";

      setTimeout(() => {
        mascote.style.left = "50px";
        mascote.style.opacity = "1";
        mascote.style.pointerEvents = "auto";
        clickCount = 0;
        darkClickCount = 0;
        mascoteTransformado = false;
      }, 600);
    }
  });
});
