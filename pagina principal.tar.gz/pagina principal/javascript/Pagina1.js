document.addEventListener("DOMContentLoaded", () => {
  // Utilitário para validar campos
  function validarCampo(campo) {
    if (!campo.value.trim() || (campo.type === "email" && !campo.checkValidity())) {
      campo.classList.add("erro-ativa");
      return false;
    } else {
      campo.classList.remove("erro-ativa");
      return true;
    }
  }

  // Exibe mensagem com foco acessível
  function exibirMensagem(elemento, texto) {
    elemento.textContent = texto;
    elemento.setAttribute("tabindex", "-1");
    elemento.focus();
  }

  // Cadastro
  const cadastroForm = document.getElementById("cadastro-form");
  const nome = document.getElementById("nome");
  const emailCadastro = document.getElementById("email");
  const senhaCadastro = document.getElementById("senha");
  const mensagemCadastro = document.getElementById("mensagem");

  cadastroForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const nomeValido = validarCampo(nome);
    const emailValido = validarCampo(emailCadastro);
    const senhaValida = validarCampo(senhaCadastro);

    if (!nomeValido || !emailValido || !senhaValida) {
      exibirMensagem(mensagemCadastro, "Por favor, corrija os campos destacados.");
    } else {
      exibirMensagem(mensagemCadastro, "Cadastro realizado com sucesso!");
      cadastroForm.reset();
    }
  });

  // Login
  const loginForm = document.getElementById("login-form");
  const loginEmail = document.getElementById("login-email");
  const loginSenha = document.getElementById("login-senha");
  const mensagemLogin = document.getElementById("mensagem-login");

  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const emailValido = validarCampo(loginEmail);
    const senhaValida = validarCampo(loginSenha);

    if (!emailValido || !senhaValida) {
      exibirMensagem(mensagemLogin, "Preencha os campos obrigatórios com informações válidas.");
    } else {
      exibirMensagem(mensagemLogin, "Login realizado com sucesso!");
      loginForm.reset();
    }
  });
});
