import { Usuario } from './usuario.js';

// Seletores do DOM
const form = document.getElementById('cadastro-form');
const nomeInput = document.getElementById('nome');
const emailInput = document.getElementById('email');
const senhaInput = document.getElementById('senha');
const mensagemDiv = document.getElementById('mensagem');

// Array para armazenar os usuários
let usuarios = [];

// Função para exibir uma mensagem temporária
function exibirMensagem(texto, tipo = 'sucesso') {
  mensagemDiv.textContent = texto;
  mensagemDiv.style.color = tipo === 'sucesso' ? 'green' : 'red';
  setTimeout(() => {
    mensagemDiv.textContent = '';
  }, 3000);
}

// Lida com o envio do formulário
form.addEventListener('submit', (evento) => {
  evento.preventDefault(); // Impede o recarregamento da página

  const nome = nomeInput.value;
  const email = emailInput.value;
  const senha = senhaInput.value;

  if (nome && email && senha) {
    // Cria uma nova instância da classe Usuario
    const novoUsuario = new Usuario(nome, email, senha);

    // Adiciona ao array de usuários
    usuarios.push(novoUsuario);

    // Exibe mensagem de sucesso e limpa o formulário
    exibirMensagem('Usuário cadastrado com sucesso!');
    form.reset();
  } else {
    exibirMensagem('Por favor, preencha todos os campos.', 'erro');
  }
});
