(function(d){
  var s = d.createElement("script");
  s.setAttribute("src", "https://cdn.userway.org/widget.js");
  s.setAttribute("data-account", "9DfFIdc1IL"); // Seu ID da UserWay
  s.setAttribute("data-lang", "pt"); // Define o idioma como português
  (d.head || d.body).appendChild(s);
})(document);