// Espera o DOM carregar
document.addEventListener('DOMContentLoaded', () => {
  const botao = document.getElementById('ativar-vlibras');

  if (botao) {
    botao.addEventListener('click', () => {
      // Espera o VLibras estar disponível
      const tentarAtivar = () => {
        const vlibrasBtn = document.querySelector('[vw-access-button]');
        if (vlibrasBtn) {
          vlibrasBtn.click();
        } else {
          // Tenta novamente após um pequeno atraso
          setTimeout(tentarAtivar, 500);
        }
      };

      tentarAtivar();
    });
  } else {
    console.warn('Botão de ativação VLibras não encontrado.');
  }
});