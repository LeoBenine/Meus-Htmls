function toggleLogin() {
  const loginBox = document.getElementById("loginBox");
  const registerBox = document.getElementById("registerBox");

  loginBox.style.display = loginBox.style.display === "none" ? "flex" : "none";
  registerBox.style.display = "none";
}

function toggleRegister() {
  const loginBox = document.getElementById("loginBox");
  const registerBox = document.getElementById("registerBox");

  registerBox.style.display = registerBox.style.display === "none" ? "flex" : "none";
  loginBox.style.display = "none";
}