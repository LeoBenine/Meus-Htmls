function toggleAnswer(element) {
  const answer = element.querySelector('.faq-answer');
  const isVisible = answer.style.display === 'block';

  document.querySelectorAll('.faq-answer').forEach(ans => {
    ans.style.display = 'none';
    ans.parentElement.setAttribute('aria-expanded', 'false');
  });

  if (!isVisible) {
    answer.style.display = 'block';
    element.setAttribute('aria-expanded', 'true');
  }
}