// usuario.js

class Usuario {
    /**
     * @param {string} nome
     * @param {string} email
     * @param {string} senha
     */
    constructor(nome, email, senha) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    /**
     * Retorna uma string formatada com os dados do usuário,
     * exceto a senha, para fins de segurança.
     * @returns {string}
     */
    exibirDados() {
        return `Nome: ${this.nome} | E-mail: ${this.email}`;
    }
}

export { Usuario };
